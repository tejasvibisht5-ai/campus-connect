
from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "campus_connect_secret_key"

# Database file will be created beside app.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "campusconnect.db")


# =====================================================
# DATABASE CONNECTION
# =====================================================

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()

    conn.executescript("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            student_id TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            department TEXT NOT NULL,
            year TEXT NOT NULL,
            phone TEXT NOT NULL,
            password TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS clubs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            faculty TEXT NOT NULL,
            description TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            phone TEXT NOT NULL,
            password TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            venue TEXT NOT NULL,
            icon TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS event_registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL,
            student_email TEXT NOT NULL COLLATE NOCASE,
            UNIQUE(event_id, student_email),
            FOREIGN KEY(event_id) REFERENCES events(id),
            FOREIGN KEY(student_email) REFERENCES students(email)
                ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS club_members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            club_id INTEGER NOT NULL,
            student_email TEXT NOT NULL COLLATE NOCASE,
            UNIQUE(club_id, student_email),
            FOREIGN KEY(club_id) REFERENCES clubs(id),
            FOREIGN KEY(student_email) REFERENCES students(email)
                ON DELETE CASCADE
        );
    """)

    # Add the four default clubs only when they don't exist.
    default_clubs = [
        (
            "Coding Club", "Technology", "Dr. Rahul Sharma",
            "Learn coding, programming and build exciting projects with fellow students.",
            "coding@gehu.ac.in", "9876543210", "coding123"
        ),
        (
            "Cultural Club", "Cultural", "Dr. Priya Singh",
            "Celebrate music, dance, art and the diverse culture of our university.",
            "cultural@gehu.ac.in", "9876543211", "cultural123"
        ),
        (
            "Sports Club", "Sports", "Dr. Amit Verma",
            "Participate in sports activities, competitions and fitness events.",
            "sports@gehu.ac.in", "9876543212", "sports123"
        ),
        (
            "Literary Club", "Literary", "Dr. Neha Joshi",
            "Explore writing, poetry, debates, storytelling and literary activities.",
            "literary@gehu.ac.in", "9876543213", "literary123"
        )
    ]

    for club in default_clubs:
        conn.execute("""
            INSERT OR IGNORE INTO clubs
            (name, category, faculty, description, email, phone, password)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            club[0], club[1], club[2], club[3], club[4],
            club[5], generate_password_hash(club[6])
        ))

    # Add default events without deleting existing registrations.
    default_events = [
        (1, "Campus Hackathon", "15 AUG 2026", "10:00 AM",
         "Main Auditorium", "💻"),
        (2, "Cultural Fest", "22 AUG 2026", "5:00 PM",
         "University Ground", "🎭"),
        (3, "Sports Meet", "28 AUG 2026", "9:00 AM",
         "Sports Complex", "🏆"),
        (4, "Coding Workshop", "05 SEP 2026", "11:00 AM",
         "Computer Lab", "💡")
    ]

    conn.executemany("""
        INSERT OR IGNORE INTO events
        (id, name, date, time, venue, icon)
        VALUES (?, ?, ?, ?, ?, ?)
    """, default_events)

    conn.commit()
    conn.close()


# Create tables and default records when the app starts.
init_db()


# =====================================================
# HOME
# =====================================================

@app.route("/")
def home():
    conn = get_db()
    events = [dict(row) for row in conn.execute(
        "SELECT * FROM events ORDER BY id"
    ).fetchall()]
    clubs = [dict(row) for row in conn.execute(
        "SELECT * FROM clubs ORDER BY id"
    ).fetchall()]
    conn.close()

    return render_template("index.html", events=events, clubs=clubs)


# =====================================================
# EVENTS PAGE
# =====================================================

@app.route("/events")
def events_page():
    conn = get_db()
    events = [dict(row) for row in conn.execute(
        "SELECT * FROM events ORDER BY id"
    ).fetchall()]
    conn.close()

    return render_template("events.html", events=events)


# =====================================================
# CLUBS PAGE
# =====================================================

@app.route("/clubs")
def clubs_page():
    conn = get_db()
    clubs = [dict(row) for row in conn.execute(
        "SELECT * FROM clubs ORDER BY id"
    ).fetchall()]
    conn.close()

    return render_template("clubs.html", clubs=clubs)


# =====================================================
# REGISTER PAGE
# =====================================================

@app.route("/register")
def register():
    return render_template("register.html")


# =====================================================
# LOGIN
# =====================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db()

        student = conn.execute(
            "SELECT * FROM students WHERE email = ?",
            (email,)
        ).fetchone()

        if student and check_password_hash(student["password"], password):
            conn.close()
            session.clear()
            session["student_email"] = student["email"]
            return redirect(url_for("student_dashboard"))

        club = conn.execute(
            "SELECT * FROM clubs WHERE email = ?",
            (email,)
        ).fetchone()

        if club and check_password_hash(club["password"], password):
            conn.close()
            session.clear()
            session["club_email"] = club["email"]
            return redirect(url_for("club_dashboard"))

        conn.close()
        return render_template(
            "login.html", error="Invalid email or password"
        )

    return render_template("login.html")


# =====================================================
# STUDENT REGISTER
# =====================================================

@app.route("/student-register", methods=["GET", "POST"])
def student_register():
    if request.method == "POST":
        student = {
            "name": request.form.get("name", "").strip(),
            "student_id": request.form.get("student_id", "").strip(),
            "email": request.form.get("email", "").strip().lower(),
            "department": request.form.get("department", "").strip(),
            "year": request.form.get("year", "").strip(),
            "phone": request.form.get("phone", "").strip(),
            "password": request.form.get("password", "")
        }

        if not all(student.values()):
            flash("Please fill in all the required fields.")
            return render_template("std-register.html")

        conn = get_db()

        existing = conn.execute("""
            SELECT id FROM students
            WHERE email = ? OR student_id = ?
        """, (student["email"], student["student_id"])).fetchone()

        if existing:
            conn.close()
            flash("This email or Student ID is already registered. Please log in.")
            return render_template("std-register.html")

        try:
            conn.execute("""
                INSERT INTO students
                (name, student_id, email, department, year, phone, password)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                student["name"],
                student["student_id"],
                student["email"],
                student["department"],
                student["year"],
                student["phone"],
                generate_password_hash(student["password"])
            ))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.rollback()
            conn.close()
            flash("This email or Student ID is already registered.")
            return render_template("std-register.html")

        conn.close()
        return redirect(url_for("student_success"))

    return render_template("std-register.html")


# =====================================================
# STUDENT SUCCESS
# =====================================================

@app.route("/student-success")
def student_success():
    return render_template("student-success.html")


# =====================================================
# CLUB REGISTER
# =====================================================

@app.route("/club-register", methods=["GET", "POST"])
def club_register():
    if request.method == "POST":
        club = {
            "name": request.form.get("club_name", "").strip(),
            "category": request.form.get("category", "").strip(),
            "faculty": request.form.get("faculty", "").strip(),
            "description": request.form.get("description", "").strip(),
            "email": request.form.get("email", "").strip().lower(),
            "phone": request.form.get("phone", "").strip(),
            "password": request.form.get("password", "")
        }

        if not all(club.values()):
            flash("Please fill in all the required fields.")
            return render_template("club-register.html")

        conn = get_db()

        try:
            conn.execute("""
                INSERT INTO clubs
                (name, category, faculty, description, email, phone, password)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                club["name"],
                club["category"],
                club["faculty"],
                club["description"],
                club["email"],
                club["phone"],
                generate_password_hash(club["password"])
            ))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.rollback()
            conn.close()
            flash("This club email is already registered.")
            return render_template("club-register.html")

        conn.close()
        return redirect(url_for("club_success"))

    return render_template("club-register.html")


# =====================================================
# CLUB SUCCESS
# =====================================================

@app.route("/club-success")
def club_success():
    return render_template("club-success.html")


# =====================================================
# REGISTER FOR EVENT
# =====================================================

@app.route("/register-event/<int:event_id>")
def register_event(event_id):
    if "student_email" not in session:
        flash("Please login as a student to register for an event.")
        return redirect(url_for("login"))

    conn = get_db()

    event = conn.execute(
        "SELECT id FROM events WHERE id = ?", (event_id,)
    ).fetchone()

    if not event:
        conn.close()
        flash("Event not found.")
        return redirect(url_for("events_page"))

    try:
        conn.execute("""
            INSERT INTO event_registrations (event_id, student_email)
            VALUES (?, ?)
        """, (event_id, session["student_email"]))
        conn.commit()
        flash("You have successfully registered for the event!")
    except sqlite3.IntegrityError:
        flash("You are already registered for this event.")

    conn.close()
    return redirect(url_for("events_page"))


# =====================================================
# JOIN CLUB
# =====================================================

@app.route("/join-club/<int:club_id>")
def join_club(club_id):
    if "student_email" not in session:
        flash("Please login as a student to join a club.")
        return redirect(url_for("login"))

    conn = get_db()

    club = conn.execute(
        "SELECT id FROM clubs WHERE id = ?", (club_id,)
    ).fetchone()

    if not club:
        conn.close()
        flash("Club not found.")
        return redirect(url_for("clubs_page"))

    try:
        conn.execute("""
            INSERT INTO club_members (club_id, student_email)
            VALUES (?, ?)
        """, (club_id, session["student_email"]))
        conn.commit()
        flash("You successfully joined the club!")
    except sqlite3.IntegrityError:
        flash("You are already a member of this club.")

    conn.close()
    return redirect(url_for("clubs_page"))


# =====================================================
# STUDENT DASHBOARD
# =====================================================

@app.route("/student-dashboard")
def student_dashboard():
    student_email = session.get("student_email")

    if not student_email:
        return redirect(url_for("login"))

    conn = get_db()

    student_row = conn.execute(
        "SELECT * FROM students WHERE email = ?", (student_email,)
    ).fetchone()

    if not student_row:
        conn.close()
        session.clear()
        return redirect(url_for("login"))

    student = dict(student_row)

    registered_events = [dict(row) for row in conn.execute("""
        SELECT e.* FROM events e
        JOIN event_registrations r ON e.id = r.event_id
        WHERE r.student_email = ?
        ORDER BY e.id
    """, (student_email,)).fetchall()]

    joined_clubs = [dict(row) for row in conn.execute("""
        SELECT c.* FROM clubs c
        JOIN club_members m ON c.id = m.club_id
        WHERE m.student_email = ?
        ORDER BY c.id
    """, (student_email,)).fetchall()]

    total_students = conn.execute(
        "SELECT COUNT(*) FROM students"
    ).fetchone()[0]

    conn.close()

    return render_template(
        "student-dashboard.html",
        student=student,
        total_students=total_students,
        registered_events=registered_events,
        joined_clubs=joined_clubs
    )


# =====================================================
# CLUB DASHBOARD
# =====================================================

@app.route("/club-dashboard")
def club_dashboard():
    club_email = session.get("club_email")

    if not club_email:
        return redirect(url_for("login"))

    conn = get_db()

    club_row = conn.execute(
        "SELECT * FROM clubs WHERE email = ?", (club_email,)
    ).fetchone()

    if not club_row:
        conn.close()
        session.clear()
        return redirect(url_for("login"))

    club = dict(club_row)

    joined_students = [dict(row) for row in conn.execute("""
        SELECT s.* FROM students s
        JOIN club_members m ON s.email = m.student_email
        WHERE m.club_id = ?
        ORDER BY s.name
    """, (club["id"],)).fetchall()]

    total_students = len(joined_students)
    conn.close()

    return render_template(
        "club-dashboard.html",
        club=club,
        students=joined_students,
        total_students=total_students
    )


# =====================================================
# STUDENT PROFILE
# =====================================================

@app.route("/profile")
def profile():
    student_email = session.get("student_email")

    if not student_email:
        return redirect(url_for("login"))

    conn = get_db()
    row = conn.execute(
        "SELECT * FROM students WHERE email = ?", (student_email,)
    ).fetchone()
    conn.close()

    if not row:
        session.clear()
        return redirect(url_for("login"))

    return render_template("profile.html", student=dict(row))


# =====================================================
# ALL STUDENTS
# =====================================================

@app.route("/students")
def students_list():
    if "club_email" not in session:
        return redirect(url_for("login"))

    conn = get_db()
    students = [dict(row) for row in conn.execute("""
        SELECT id, name, student_id, email, department, year, phone
        FROM students
        ORDER BY name
    """).fetchall()]
    conn.close()

    return render_template("students.html", students=students)


# =====================================================
# STUDENT PROFILE FOR CLUB
# =====================================================

@app.route("/student-profile/<student_id>")
def student_profile(student_id):
    if "club_email" not in session:
        return redirect(url_for("login"))

    conn = get_db()
    row = conn.execute("""
        SELECT id, name, student_id, email, department, year, phone
        FROM students
        WHERE student_id = ?
    """, (student_id,)).fetchone()
    conn.close()

    if not row:
        return "Student not found", 404

    return render_template("student-profile.html", student=dict(row))


# =====================================================
# LOGOUT
# =====================================================

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    app.run(debug=True)
