#include <stdio.h>

#define SIZE 10

int arr[SIZE];
int top1 = -1;
int top2 = SIZE;

void push1(int value)
{
    if (top1 + 1 == top2)
        printf("Stack Overflow\n");
    else
    {
        top1++;
        arr[top1] = value;
    }
}

void push2(int value)
{
    if (top1 + 1 == top2)
        printf("Stack Overflow\n");
    else
    {
        top2--;
        arr[top2] = value;
    }
}

void pop1()
{
    if (top1 == -1)
        printf("Stack 1 Underflow\n");
    else
    {
        printf("Deleted from Stack 1: %d\n", arr[top1]);
        top1--;
    }
}

void pop2()
{
    if (top2 == SIZE)
        printf("Stack 2 Underflow\n");
    else
    {
        printf("Deleted from Stack 2: %d\n", arr[top2]);
        top2++;
    }
}

void display()
{
    int i;

    printf("\nStack 1: ");
    if (top1 == -1)
        printf("Empty");
    else
        for (i = 0; i <= top1; i++)
            printf("%d ", arr[i]);

    printf("\nStack 2: ");
    if (top2 == SIZE)
        printf("Empty");
    else
        for (i = SIZE - 1; i >= top2; i--)
            printf("%d ", arr[i]);

    printf("\n");
}

int main()
{
    int choice, value;

    while (1)
    {
        printf("\n--- TWO STACKS IN ONE ARRAY ---\n");
        printf("1. Push in Stack 1\n");
        printf("2. Push in Stack 2\n");
        printf("3. Pop from Stack 1\n");
        printf("4. Pop from Stack 2\n");
        printf("5. Display\n");
        printf("6. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Enter value: ");
                scanf("%d", &value);
                push1(value);
                break;

            case 2:
                printf("Enter value: ");
                scanf("%d", &value);
                push2(value);
                break;

            case 3:
                pop1();
                break;

            case 4:
                pop2();
                break;

            case 5:
                display();
                break;

            case 6:
                return 0;

            default:
                printf("Invalid choice\n");
        }
    }
}